﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PrimeFibonacci.Controllers
{
    public class PrintNumberController : Controller
    {
        // GET: PrintNumber
        public ActionResult PrimeNumbers(int id)
        {
            ViewData["data"] = id;
            return View();
        }
        public ActionResult Fibonacci(int id)
        {
            ViewData["data"] = id;
            return View();
        }
    }
}